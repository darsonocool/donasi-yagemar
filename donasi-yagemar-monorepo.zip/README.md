# donasi-yagemar

Monorepo for Yayasan Gema Akhlaqul Karimah donation app.

This repo includes frontend (React) and backend (Express + MongoDB) and GitHub Actions to auto-deploy to Vercel.
