# Backend (donasi-yagemar)

Copy `.env.example` -> `.env` and fill MONGODB_URI, JWT_SECRET, ADMIN_EMAIL, ADMIN_PASS.

Local dev:

```
cd backend
npm install
npm run dev
```

When deployed to Vercel, GitHub Actions will create `.env` from repo secrets.
