import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import Admin from '../models/Admin.js';
dotenv.config();
const SECRET = process.env.JWT_SECRET || 'dev_secret';

export default async function authMiddleware(req, res, next){
  const auth = req.headers.authorization;
  if(!auth?.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });
  const token = auth.slice(7);
  try{
    const payload = jwt.verify(token, SECRET);
    const admin = await Admin.findById(payload.id);
    if(!admin) return res.status(401).json({ error: 'Unauthorized' });
    req.admin = { id: admin._id, email: admin.email };
    next();
  }catch(err){
    return res.status(401).json({ error: 'Invalid token' });
  }
}
