import mongoose from 'mongoose';
const Schema = mongoose.Schema;
const CampaignSchema = new Schema({
  title: { type: String, required: true },
  description: String,
  goal: { type: Number, default: 0 },
  collected: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});
CampaignSchema.pre('save', function(next){ this.updatedAt = Date.now(); next(); });
export default mongoose.model('Campaign', CampaignSchema);
