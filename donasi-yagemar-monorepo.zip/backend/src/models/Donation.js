import mongoose from 'mongoose';
const Schema = mongoose.Schema;
const DonationSchema = new Schema({
  campaignId: { type: Schema.Types.ObjectId, ref: 'Campaign', required: true },
  name: { type: String, required: true },
  email: { type: String, required: true },
  amount: { type: Number, required: true },
  anonymous: { type: Boolean, default: false },
  status: { type: String, default: 'paid' },
  createdAt: { type: Date, default: Date.now }
});
export default mongoose.model('Donation', DonationSchema);
