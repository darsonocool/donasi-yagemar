import express from 'express';
import Campaign from '../models/Campaign.js';
import auth from '../middleware/auth.js';
const router = express.Router();

router.get('/', async (req, res) => {
  const camps = await Campaign.find().sort({ createdAt: -1 });
  res.json(camps);
});

router.post('/', auth, async (req, res) => {
  const { title, description, goal } = req.body;
  if(!title || goal == null) return res.status(400).json({ error: 'title & goal required' });
  const camp = await Campaign.create({ title, description, goal: Number(goal) });
  res.json(camp);
});

router.put('/:id', auth, async (req, res) => {
  const id = req.params.id;
  const { title, description, goal } = req.body;
  const updated = await Campaign.findByIdAndUpdate(id, { title, description, goal: Number(goal), updatedAt: Date.now() }, { new: true });
  res.json(updated);
});

router.delete('/:id', auth, async (req, res) => {
  await Campaign.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

export default router;
