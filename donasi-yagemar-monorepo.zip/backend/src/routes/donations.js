import express from 'express';
import Donation from '../models/Donation.js';
import Campaign from '../models/Campaign.js';
import auth from '../middleware/auth.js';
import { stringify } from 'csv-stringify/sync';
const router = express.Router();

router.post('/', async (req, res) => {
  const { campaignId, name, email, amount, anonymous } = req.body;
  if(!campaignId || !name || !email || !amount) return res.status(400).json({ error: 'missing fields' });
  const donation = await Donation.create({ campaignId, name, email, amount: Number(amount), anonymous: !!anonymous, status: 'paid' });
  await Campaign.findByIdAndUpdate(campaignId, { $inc: { collected: Number(amount) } });
  res.json(donation);
});

router.get('/', auth, async (req, res) => {
  const list = await Donation.find().sort({ createdAt: -1 }).populate('campaignId');
  res.json(list);
});

router.get('/export/csv', auth, async (req, res) => {
  const list = await Donation.find().sort({ createdAt: -1 }).populate('campaignId');
  const header = ['id','campaignId','campaignTitle','name','email','amount','anonymous','status','createdAt'];
  const rows = list.map(d => [d._id.toString(), d.campaignId?._id?.toString()||'', d.campaignId?.title||'', d.name, d.email, d.amount, d.anonymous, d.status, d.createdAt.toISOString()]);
  const csv = stringify([header, ...rows]);
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="donations_gak.csv"');
  res.send(csv);
});

export default router;
