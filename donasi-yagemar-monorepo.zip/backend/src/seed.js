import Admin from './models/Admin.js';
import bcrypt from 'bcrypt';
import dotenv from 'dotenv';
dotenv.config();

export default async function seedAdmin(){
  try {
    const email = process.env.ADMIN_EMAIL;
    const pass = process.env.ADMIN_PASS;
    if(!email || !pass) return;
    const existing = await Admin.findOne({ email });
    if(existing) return;
    const hash = await bcrypt.hash(pass, 10);
    await Admin.create({ email, password: hash });
    console.log('Seeded admin:', email);
  } catch(err) {
    console.error('Seed admin error:', err);
  }
}
