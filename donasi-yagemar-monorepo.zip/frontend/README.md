# Frontend (donasi-yagemar)

Copy `.env.example` -> `.env` and set VITE_API_BASE if running locally.

Local dev:

```
cd frontend
npm install
npm run dev
```

When deployed, GitHub Actions will create `.env` from repo secrets.
