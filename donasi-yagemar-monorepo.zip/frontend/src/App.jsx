import React, { useEffect, useState } from 'react';
import axios from 'axios';
const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000/api';

export default function App(){
  const [campaigns, setCampaigns] = useState([]);
  const [view, setView] = useState('home');
  const [form, setForm] = useState({ campaignId:'', name:'', email:'', amount:'' });
  const [token, setToken] = useState(localStorage.getItem('gak_token')||'');

  useEffect(()=>{ fetchCampaigns(); }, []);
  async function fetchCampaigns(){ try{ const res = await axios.get(API_BASE + '/campaigns'); setCampaigns(res.data); if(res.data[0]) setForm(f=>({ ...f, campaignId: res.data[0]._id })); }catch(e){console.error(e);} }

  async function donate(e){ e.preventDefault(); await axios.post(API_BASE + '/donations', { ...form }); alert('Terima kasih, donasi tercatat (demo)'); setView('home'); fetchCampaigns(); setForm({ campaignId: form.campaignId, name:'', email:'', amount:'' }); }

  async function adminLogin(email, password){ const res = await axios.post(API_BASE + '/auth/login', { email, password }); localStorage.setItem('gak_token', res.data.token); setToken(res.data.token); alert('Login sukses'); }

  return (<div className='container'>
    <header style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
      <h1>Yayasan Gema Akhlaqul Karimah</h1>
      <nav>
        <button onClick={()=>setView('home')}>Beranda</button>{' '}
        <button onClick={()=>setView('donate')}>Donasi</button>{' '}
        <button onClick={()=>setView('admin')}>Admin</button>
      </nav>
    </header>

    {view==='home' && <section>
      <h2>Kampanye</h2>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        {campaigns.map(c=>(
          <div key={c._id} style={{background:'#fff',padding:12,borderRadius:8}}>
            <h3>{c.title}</h3>
            <p>{c.description}</p>
            <div>Terkumpul: Rp {c.collected} / Rp {c.goal}</div>
            <button onClick={()=>{ setForm(f=>({ ...f, campaignId: c._id })); setView('donate'); }}>Donasi</button>
          </div>
        ))}
      </div>
    </section>}

    {view==='donate' && <section>
      <h2>Form Donasi</h2>
      <form onSubmit={donate}>
        <label>Pilih Kampanye<br/>
          <select value={form.campaignId} onChange={e=>setForm({...form, campaignId:e.target.value})}>
            {campaigns.map(c=><option key={c._id} value={c._id}>{c.title}</option>)}
          </select>
        </label><br/>
        <label>Nama<br/><input value={form.name} onChange={e=>setForm({...form, name:e.target.value})} /></label><br/>
        <label>Email<br/><input value={form.email} onChange={e=>setForm({...form, email:e.target.value})} /></label><br/>
        <label>Jumlah (Rp)<br/><input type='number' value={form.amount} onChange={e=>setForm({...form, amount:e.target.value})} /></label><br/>
        <button type='submit'>Bayar (Demo)</button> <button type='button' onClick={()=>setView('home')}>Batal</button>
      </form>
    </section>}

    {view==='admin' && <AdminPanel token={token} onLogin={adminLogin} />}

  </div>);
}

function AdminPanel({ token, onLogin }){
  const [email, setEmail] = useState('admin@gak.org');
  const [pass, setPass] = useState('admin123');
  const [donations, setDonations] = useState([]);

  async function load(){
    try{
      const res = await fetch((import.meta.env.VITE_API_BASE||'http://localhost:4000/api') + '/donations', { headers: { Authorization: 'Bearer ' + localStorage.getItem('gak_token') } });
      if(res.ok){ const data = await res.json(); setDonations(data); } else { setDonations([]); }
    }catch(e){ console.error(e); }
  }

  return (<div>
    {!token ? (<div>
      <h3>Admin Login (demo)</h3>
      <label>Email<br/><input value={email} onChange={e=>setEmail(e.target.value)} /></label><br/>
      <label>Password<br/><input type='password' value={pass} onChange={e=>setPass(e.target.value)} /></label><br/>
      <button onClick={()=>onLogin(email, pass)}>Login</button>
    </div>) : (<div>
      <h3>Dashboard</h3>
      <button onClick={load}>Load Donasi</button>
      <div>
        {donations.map(d=>(<div key={d._id} style={{background:'#fff',margin:6,padding:6}}>
          <div>{d.name} - Rp {d.amount} - {d.email}</div>
        </div>))}
      </div>
    </div>)}
  </div>);
}
